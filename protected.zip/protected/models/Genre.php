<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "genre".
 *
 * @property int $genre_id
 * @property string $name
 *
 * @property GameTbl[] $gameTbls
 */
class Genre extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'genre';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['name'], 'string', 'max' => 30],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'genre_id' => 'Genre ID',
            'name' => 'Name',
        ];
    }

    /**
     * Gets query for [[GameTbls]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGameTbls()
    {
        return $this->hasMany(GameTbl::className(), ['genre_id' => 'genre_id']);
    }
}
