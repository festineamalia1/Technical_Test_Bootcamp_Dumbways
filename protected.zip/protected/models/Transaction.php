<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "transaction".
 *
 * @property int $id_trans
 * @property int $price
 * @property int $stock
 * @property int $game_id
 *
 * @property GameTbl $game
 */
class Transaction extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transaction';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['price', 'stock', 'game_id'], 'required'],
            [['price', 'stock', 'game_id'], 'integer'],
            [['game_id'], 'exist', 'skipOnError' => true, 'targetClass' => GameTbl::className(), 'targetAttribute' => ['game_id' => 'game_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_trans' => 'Id Trans',
            'price' => 'Price',
            'stock' => 'Stock',
            'game_id' => 'Game ID',
        ];
    }

    /**
     * Gets query for [[Game]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGame()
    {
        return $this->hasOne(GameTbl::className(), ['game_id' => 'game_id']);
    }
}
