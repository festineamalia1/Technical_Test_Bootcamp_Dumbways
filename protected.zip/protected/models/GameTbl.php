<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "game_tbl".
 *
 * @property int $game_id
 * @property string $title
 * @property string $image
 * @property int $genre_id
 *
 * @property Genre $genre
 * @property Transaction[] $transactions
 */
class GameTbl extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'game_tbl';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['title', 'image', 'genre_id'], 'required'],
            [['genre_id'], 'integer'],
            [['title', 'image'], 'string', 'max' => 30],
            [['genre_id'], 'exist', 'skipOnError' => true, 'targetClass' => Genre::className(), 'targetAttribute' => ['genre_id' => 'genre_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'game_id' => 'Game ID',
            'title' => 'Title',
            'image' => 'Image',
            'genre_id' => 'Genre ID',
        ];
    }

    /**
     * Gets query for [[Genre]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGenre()
    {
        return $this->hasOne(Genre::className(), ['genre_id' => 'genre_id']);
    }

    /**
     * Gets query for [[Transactions]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasMany(Transaction::className(), ['game_id' => 'game_id']);
    }
}
