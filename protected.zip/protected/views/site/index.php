<?php

/* @var $this yii\web\View */

$this->title = 'DW-Game Center';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>DW-Game Center</h1>

        <p class="lead">Selamat Datang di DW-Game Center</p>

       
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Killing Floor</h2>
                <img src="Killing.png">
                
<p>Genre : Gore</p>
<p>Genre : Rp.50.000,00</p>
                <p><a class="btn btn-default" href="#">Beli</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Dread Out</h2>
<img src="Dread2.png">
                
<p>Genre : Horor</p>
<p>Genre : Rp.50.000,00</p>
                

                <p><a class="btn btn-default" href="#">Beli</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Granny</h2>
<img src="granny.png">
                
<p>Genre : Horor</p>
<p>Genre : Rp.50.000,00</p>

                <p><a class="btn btn-default" href="#">Beli</a></p>
            </div>
        </div>

    </div>
</div>
