<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\GameTbl */

$this->title = 'Update Game Tbl: ' . $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Game Tbls', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->title, 'url' => ['view', 'id' => $model->game_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="game-tbl-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
